﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DccyOrigination.Migrations
{
    public partial class MyFirstMigrationtimecheck : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
