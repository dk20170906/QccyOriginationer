﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DccyOrigination.EF
{
    /// <summary>
    /// 数据库操作接口
    /// </summary>
    public interface IRepository
    {
        int testModel(dynamic dynamic);
    }
}
