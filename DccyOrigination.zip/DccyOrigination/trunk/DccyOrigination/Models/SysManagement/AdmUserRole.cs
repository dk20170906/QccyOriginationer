﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace DccyOrigination.Models.SysManagement
{
    [Table("admUserRole")]
    public class AdmUserRole:AdmRelationModel
    {   
        public int AdmUserId { get; set; }
        public int AdmRoleId { get; set; }
    }
}
